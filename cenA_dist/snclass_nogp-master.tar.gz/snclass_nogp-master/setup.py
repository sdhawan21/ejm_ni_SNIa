"""Configure snclass instalation."""

from setuptools import setup
import snclass_nogp

def readme():
    """Return README.md file."""
    with open('README.md') as my_doc:
        return my_doc.read()

setup(name='snclass_nogp',
      version=snclass_nogp.__version__,
      description='Python SN photometric classifier',
      long_description=readme(),
      url='https://github.com/emilleishida/snclass',
      author=snclass_nogp.__author__,
      author_email=snclass_nogp.__email__,
      license='GPL3',
      packages=['snclass_nogp'],
      install_requires=[
                      'numpy>=1.8.2',
                      'matplotlib>=1.3.1'
      ],
      scripts=['snclass_nogp/bin/plot_lc.py', 
               'snclass_nogp/bin/build_synthetic_spec.py'],
      package_dir={'snclass_nogp': 'snclass_nogp', 'examples':'snclass_nogp/examples',
                   'ishida2015':'snclass/ishida2015'},
      zip_safe=False,
      classifiers=[
        'Programming Language :: Python',
        'Natural Language :: English',
        'Environment :: X11 Applications',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: GNU General Public License (GPL)',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Scientific/Engineering :: Astronomy',
        ])
