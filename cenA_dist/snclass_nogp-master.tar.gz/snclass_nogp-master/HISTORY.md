---------------------------------------------------------------
April 11, 2015
1. do exactly as stated in README:
         - fitting and plotting one LC - ok
         - plotting an existing result - ok
2. updated github
3. change README for markdown (rst was not working properly)
4. do exactly as stated in REAMDE:
         - build spectroscopic list - ok
         - build photo list - ok
5. correct plotting script to take george out of the title
6. begin writting functions to build data matrix (matrix.py)
7. progress in:
         - till check_epoch - ok
         - after that not tested 
----------------------------------------------------------------
April 16, 2015
1. check code. Everything ok until check_epoch
2. fix build_steps
3. finished build_steps
4. started constructing the DataMatrix object
        this should construct the initial data matrix
5. finished code to construct initial data matrix
    there is still something wrong with the GP fitting. 
    in ~150 objects with SNR>5 at least 30 are problematic. 
----------------------------------------------------------------
May 22, 2015
1. Changed GP code to gptools. 
   Fixed problematic fitting. 
----------------------------------------------------------------
May 26, 2015
1. Included a separate function for fitting a set of objects. 
2. Separated the fitting from the matrix building algorithms. 
3. Improved the output format for the mean and samples.


