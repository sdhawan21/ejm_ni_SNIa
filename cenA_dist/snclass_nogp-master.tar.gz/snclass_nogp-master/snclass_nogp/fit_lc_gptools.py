"""
Created by Emille Ishida in May, 2015.
"""

import numpy as np
import os

def save_result(data, mean=True, samples=False):
    """
    Save results of GP fit to file.

    input: data, dict
           dictionary of raw data
           output from read_snana_lc
           keys: filters

           mean, bool - optional
           if True, save mean GP fit
           Default is True

           samples, bool - optional
           if True, save draws from GP fit
           Default is False
    """
    # check if storage directory exsts
    if not os.path.exists(data['samples_dir'][0]):
        os.makedirs(data['samples_dir'][0])

    if samples:
        op1 = open(data['samples_dir'][0] + data['file_root'][0] +
                   data['SNID:'][0] + '_samples.dat', 'w')
        op1.write('filter    MJD    ')
        xfil = data['filters'][0]
        for j in xrange(len(data['realizations'][xfil])):
            op1.write('samp' + str(j + 1) + '    ')
        op1.write('\n')
        for fil in data['filters']:
            for i in xrange(len(data['xarr'][fil])):
                op1.write(fil + '    ' +
                          str(data['xarr'][fil][i]) + '    ')
                for j in xrange(len(data['realizations'][xfil])):
                    op1.write(str(data['realizations'][fil][j][i]) +
                              '    ')
                op1.write('\n')
        op1.close()

    if mean:
        op2 = open(data['samples_dir'][0] + data['file_root'][0] +
                   data['SNID:'][0] + '_mean.dat', 'w')
        op2.write('filter    MJD    GP_fit     GP_std')
        if 'SIM_NON1a:' in data.keys():
                op2.write('    type\n')
        else:
            op2.write('\n')

        for fil in data['filters']:
            for k in xrange(len(data['xarr'][fil])):
                op2.write(fil + '    ' + str(data['xarr'][fil][k]) +
                          '    ' + str(data['GP_fit'][fil][k]) +
                          '    ' + str(data['GP_std'][fil][k]))
                if 'SIM_NON1a:' in data.keys():
                    op2.write('    ' + str(data['SIM_NON1a:'][0]) + '\n')
                else:
                    op2.write('\n')
        op2.close()



def main():
    """Print documentation."""
    print __doc__

if __name__ == '__main__':
    main()
